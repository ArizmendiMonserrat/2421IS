new Sortable(pendientes, {
    group: 'shared', // set both lists to same group
    animation: 150
});

new Sortable(proceso, {
    group: 'shared',
    animation: 150
});
new Sortable(completada, {
    group: 'shared',
    animation: 150
});